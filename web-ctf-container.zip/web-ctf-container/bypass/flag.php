<?php
$flag="ncd4{we don't forget we don't forgive}";
