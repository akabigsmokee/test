<?php
$flag="ncd4{netc0mday is the  maGic}";
