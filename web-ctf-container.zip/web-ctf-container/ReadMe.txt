Then run docker build -t "web-ctf-container" . and wait untill it's done
If the build is clear, run this command docker run --name web-ctf -d -it -p 80:80 web-ctf-container

