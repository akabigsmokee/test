<?php
$flag="ncd4{you have a good mindset}";
