<?php
$flag="ncd4{y0u_g0t_1t}";
