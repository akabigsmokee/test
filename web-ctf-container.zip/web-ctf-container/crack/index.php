<!DOCTYPE HTML>
<html>
  <title>Crack the Password</title>
  <head>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  <style>
    .corb-body { background-color: #0fbcf9;}

    .centered {
      position: fixed;
      top: 50%;
      left: 50%;
      /* bring your own prefixes */
      transform: translate(-50%, -50%);
    }

    .corb-login-length { width: 200px;}
    .corb-submit { position: relative; left: auto; right: -120px;}
    .corb-flag { color: #ffffff; }
    .corb-alert { margin-top: 20px; }
  </style>
  </head>
  <body class="corb-body container-fluid">
<?php
require 'flag.php';
if (isset($_POST['password'])) {
    if (strcmp($_POST['password'], $flag) == 0)
    echo('<h1><div class="alert alert-success centered" role="alert"> Flag: '.$flag.' </div></h1>');
    else
    echo('<h1><div class="alert alert-danger centered" role="alert">Sorry, Wrong password!</div></h1>');
die;
}
?>
</div>
<div class="row">
      <div class="centered">
        <div class="well">
          <center><h3 class="corb-login-length">Password login</h3></center>
          <br/>
          <form method="POST">
          <input name="password" class="form-control" type="text" placeholder="Password">
          <br/>
          <button class="corb-submit btn btn-primary btn-lg" type="submit">Submit</button>
          </form>
        </div>
      </div>
    </div>
 <script
          src="https://code.jquery.com/jquery-3.1.1.min.js"
          integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
          crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>
    function _0x3cdb(){var _0xa89d8d=['4dEerOe','value','762720sgwKFC','Hello,\x20','5791888URuJXV','9245412Qorjoy','7674930EBqhfd','154BWrVJe','4261731feYMrf','display','4SJGWek','7oDCtSX','1653996SSqmed','1685UEdJEb','getElementById','innerHTML','2202GaPJHa'];_0x3cdb=function(){return _0xa89d8d;};return _0x3cdb();}function _0x22ed(_0x87bf28,_0x25799e){var _0x3cdbee=_0x3cdb();return _0x22ed=function(_0x22ed9f,_0x3ab2e2){_0x22ed9f=_0x22ed9f-0x1d8;var _0x2ccfe1=_0x3cdbee[_0x22ed9f];return _0x2ccfe1;},_0x22ed(_0x87bf28,_0x25799e);}(function(_0x3e6d79,_0x552fd7){var _0x2c68b6=_0x22ed,_0x34d6bb=_0x3e6d79();while(!![]){try{var _0x37ba3e=parseInt(_0x2c68b6(0x1dd))/0x1*(parseInt(_0x2c68b6(0x1e5))/0x2)+-parseInt(_0x2c68b6(0x1e3))/0x3*(parseInt(_0x2c68b6(0x1db))/0x4)+-parseInt(_0x2c68b6(0x1e8))/0x5*(parseInt(_0x2c68b6(0x1da))/0x6)+parseInt(_0x2c68b6(0x1e6))/0x7*(parseInt(_0x2c68b6(0x1df))/0x8)+-parseInt(_0x2c68b6(0x1e0))/0x9+-parseInt(_0x2c68b6(0x1e1))/0xa+-parseInt(_0x2c68b6(0x1e2))/0xb*(-parseInt(_0x2c68b6(0x1e7))/0xc);if(_0x37ba3e===_0x552fd7)break;else _0x34d6bb['push'](_0x34d6bb['shift']());}catch(_0x249748){_0x34d6bb['push'](_0x34d6bb['shift']());}}}(_0x3cdb,0xcd187));function displayName(){var _0x416a63=_0x22ed,_0x1b4393=document[_0x416a63(0x1d8)]('name')[_0x416a63(0x1dc)];document[_0x416a63(0x1d8)](_0x416a63(0x1e4))[_0x416a63(0x1d9)]=_0x416a63(0x1de)+_0x1b4393;}
  </script>
  <script>
    (function(_0x5e545d,_0x3d0e31){var _0x2ac11d=_0x2d85,_0x207479=_0x5e545d();while(!![]){try{var _0x2ae1bb=-parseInt(_0x2ac11d(0x1b5))/0x1*(parseInt(_0x2ac11d(0x1ae))/0x2)+-parseInt(_0x2ac11d(0x1b1))/0x3*(-parseInt(_0x2ac11d(0x1ac))/0x4)+-parseInt(_0x2ac11d(0x1af))/0x5*(-parseInt(_0x2ac11d(0x1b4))/0x6)+parseInt(_0x2ac11d(0x1b6))/0x7*(-parseInt(_0x2ac11d(0x1ad))/0x8)+parseInt(_0x2ac11d(0x1aa))/0x9*(parseInt(_0x2ac11d(0x1b2))/0xa)+parseInt(_0x2ac11d(0x1b0))/0xb+-parseInt(_0x2ac11d(0x1ab))/0xc;if(_0x2ae1bb===_0x3d0e31)break;else _0x207479['push'](_0x207479['shift']());}catch(_0x54a112){_0x207479['push'](_0x207479['shift']());}}}(_0xde2f,0xe958e));function decryptFlag(_0x52cbc3){var _0x1bb537=atob(_0x52cbc3);return _0x1bb537;}function _0x2d85(_0x9b8d66,_0x509065){var _0xde2f77=_0xde2f();return _0x2d85=function(_0x2d8588,_0x175148){_0x2d8588=_0x2d8588-0x1aa;var _0x2a763c=_0xde2f77[_0x2d8588];return _0x2a763c;},_0x2d85(_0x9b8d66,_0x509065);}function _0xde2f(){var _0x2d3052=['1147720QAovxi','Congratulations!\x20You\x20have\x20successfully\x20exploited\x20the\x20XSS\x20vulnerability\x20and\x20retrieved\x20the\x20flag:\x20','18DVQzco','29836380EqptPv','112VLDzBj','8Sjwvqi','6MryFNj','70285pkyTGQ','17764593DlTrLo','140850jiHpyQ','7056340hhoPuz','bmNkNHt5MHVfZzB0XzF0fQo=','258tzIlAt','446389qwSRwv'];_0xde2f=function(){return _0x2d3052;};return _0xde2f();}function getFlag(){var _0x49f373=_0x2d85,_0x5684a3=_0x49f373(0x1b3),_0x266923=decryptFlag(_0x5684a3);alert(_0x49f373(0x1b7)+_0x266923);}
  </script>
  </body>
  <!-- password:flag-->
</html>
