<?php
$flag="ncd4{hihihi,how 4re y0u the t0day}";
